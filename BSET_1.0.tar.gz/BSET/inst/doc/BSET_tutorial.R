## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ----install-BSET-------------------------------------------------------------
# install.packages("pak")
# pak::pak("PietroCarlotti/BSET")

## ----packages, message=FALSE, warning=FALSE-----------------------------------
library(ggplot2)
library(dplyr)

## ----set-seed-----------------------------------------------------------------
# Set the random seed for reproducibility
set.seed(123)

## ----generate-data-no-X-------------------------------------------------------
# Sample size
n <- 50

# Treatment assignment probability
p <- 0.5

# Mean vector of potential outcomes for the primary outcome and the surrogate
mu_star <- c(6, 6, 2.5, 2.5)

# Covariance matrix of potential outcomes for the primary outcome and the surrogate
Sigma_star <- kronecker(
  diag(2),
  matrix(
    data = c(3, 3,
             3, 3.1),
    nrow = 2,
    ncol = 2)
)

# Generate the data
data_no_X <- BSET::DGP_no_X(
  n = n,
  p = p,
  mu_star = mu_star,
  Sigma_star = Sigma_star,
  model = "Gaussian"
)

## ----generate-data-X----------------------------------------------------------
# Sample size
n <- 50

# Treatment assignment probability
p <- 0.5

# Binary covariate probability
q <- 0.5

# Mean vector for potential outcomes when X = 0 and when X = 1
mu_0 <- c(5, 5, 0, 0)
mu_1 <- c(5, -5, 0, -10)

# Covariance matrix for potential outcomes when X = 0 and when X = 1
Sigma_0 <- kronecker(
  diag(2),
  matrix(
    data = c(1, 1,
             1, 2),
    nrow = 2,
    ncol = 2)
  )

Sigma_1 <- kronecker(
  diag(2),
  matrix(
    data = c(1, 1,
             1, 2),
    nrow = 2,
    ncol = 2)
  )

# Generate the data
data_X <- BSET::DGP_X_binary(
  n = n,
  p = p,
  q = q,
  mu_0 = mu_0,
  mu_1 = mu_1,
  Sigma_0 = Sigma_0,
  Sigma_1 = Sigma_1
  )

## ----compute-delta-theta-no-X-------------------------------------------------
# Compute delta
delta_no_X <- BSET::compute_delta(MC_data = data_no_X)

# Compute theta
theta_no_X <- BSET::compute_theta(MC_data = data_no_X)

## ----compute-delta-theta-X----------------------------------------------------
# Compute delta
delta_X <- BSET::compute_delta(MC_data = data_X)

# Compute theta
theta_X <- BSET::compute_theta(MC_data = data_X)

## ----delta-theta-table, echo=FALSE--------------------------------------------
delta_theta_table <- data.frame(
  Setting = c("No X (Perfect Surrogate)", "Binary X"),
  "$\\widehat{\\delta}$" = c(delta_no_X$delta, delta_X$delta),
  "$\\widehat{\\theta}$" = c(theta_no_X$theta, theta_X$theta),
  check.names = FALSE 
)

knitr::kable(
  delta_theta_table, 
  caption = "Estimated values of $\\delta$ and $\\theta$ in the two settings.",
  escape = FALSE,
  booktabs = TRUE,
  align = "ccc",
  digits = 3
)

## ----compute-delta-theta-true-------------------------------------------------
# Number of Monte Carlo samples to generate per setting
MC_samples <- 10#00000

# Compute the true values of delta and theta for all settings of Parast et al. (2024)
estimands_Parast_et_al_2024 <- BSET::compute_estimands_Parast_et_al_2024(MC_samples)

# Compute the true values of delta and theta for all settings of Carlotti and Parast (2026)
estimands_Carlotti_and_Parast_2026 <- BSET::compute_estimands_Carlotti_and_Parast_2026(MC_samples)

## ----estimands-Parast-et-al-2024, echo=FALSE----------------------------------
estimands_Parast_et_al_2024_table <- data.frame(
  Setting = c("Useless surrogate", "Perfect surrogate", "Imperfect surrogate", "Misspecified model"),
  "$\\delta$" = estimands_Parast_et_al_2024$delta_MC,
  "$\\theta$" = estimands_Parast_et_al_2024$theta_MC,
  check.names = FALSE
)

knitr::kable(
  estimands_Parast_et_al_2024_table,
  caption = "Monte Carlo estimates of $\\delta$ and $\\theta$ for the simulation settings considered in Parast et al. (2024).",
  booktabs = TRUE,
  align = "ccc",
  digits = 3
)

## ----estimands-Carlotti-and-Parast-2026, echo=FALSE---------------------------
estimands_Carlotti_and_Parast_2026_table <- data.frame(
  Setting = c("Perfect surrogate"),
  "$\\delta$" = estimands_Carlotti_and_Parast_2026$delta_MC,
  "$\\theta$" = estimands_Carlotti_and_Parast_2026$theta_MC,
  check.names = FALSE
)

knitr::kable(
  estimands_Carlotti_and_Parast_2026_table,
  caption = "Monte Carlo estimates of $\\delta$ and $\\theta$ for the simulation settings considered in Carlotti and Parast (2026).",
  booktabs = TRUE,
  align = "ccc",
  digits = 3
)

## ----compute-BF-distribution--------------------------------------------------
# Sample size
n <- 50

# Hypothesized value of V_S under the null
V_S_zero <- 0.5

# Prior parameters for the Beta distribution
a <- 1
b <- 1

# Alternative hypothesis for the Bayes factor
BF_alternative <- "greater"

# Compute the distribution of the Bayes factor
BF_distribution <- BSET::compute_BF_distribution(
  n = n,
  V_S_true = V_S_zero,
  V_S_zero = V_S_zero,
  a = a,
  b = b,
  BF_alternative = BF_alternative
)

## ----BF-distribution-plot, echo=FALSE, fig.width=8, fig.height=4.5, fig.align='center', fig.cap="Distribution of the Bayes factor under the null hypothesis $V_S = 0.5$."----
# Log transform the Bayes factor
BF_distribution$log_BF_values <- log(BF_distribution$BF_values)

ggplot(BF_distribution, aes(x = log_BF_values, y = BF_PMF)) +
  geom_col(fill = "steelblue", width = 0.07) +
  labs(
    x = expression(log(BF[n])),
    y = "PMF"
  ) +
  theme_minimal()

## ----compute-BF-alpha---------------------------------------------------------
# Type I error rate
alpha <- 0.05

# Compute the critical value of the Bayes factor corresponding to alpha
BF_alpha <- BF_distribution %>%
    dplyr::filter(BF_CDF >= 1 - alpha) %>%
    dplyr::slice(1) %>%
    dplyr::pull(BF_values)

## ----compute-V_S-star---------------------------------------------------------
# Type II error rate
beta <- 0.2

# Compute the value of v_S that satisfies the power constraint
V_S_star <- BSET::compute_V_S_star(
  n = n,
  alpha = alpha,
  beta = beta,
  V_S_zero = V_S_zero,
  a = a,
  b = b,
  BF_alternative = BF_alternative,
  root_tolerance = 1e-16
)$V_S_star

## ----compute-eta--------------------------------------------------------------
# Hypothesized value of the treatment effect on the primary outcome
v_Y <- estimands_Parast_et_al_2024$V_Y_MC[2]

# Compute the validation threshold eta
eta <- max(v_Y - V_S_star, 0)

## ----BSET-no-X-data-----------------------------------------------------------
# Prepare the data for BSET_no_X
BSET_no_X_data <- data.frame(
  Y = data_no_X$P_observed[, "Y"],
  S = data_no_X$P_observed[, "S"],
  Z = data_no_X$Z 
)

## ----BSET-no-X-posterior-sampling-parameters----------------------------------
# Posterior sampling parameters
n_chains <- 2
n_iter <- 2000
burn_in_ratio <- 0.25

## ----BSET-no-X-prior-parameters-----------------------------------------------
# Prior parameters
mu_0 <- rep(0, 4)
Sigma_0 <- diag(4)
s <- rep(1, 4)
tau <- 1

## ----BSET-no-X----------------------------------------------------------------
# Run the BSET procedure without adjusting for covariates
BSET_no_X_results <- BSET::BSET_no_X(
  data = BSET_no_X_data,
  Y = "Y",
  S = "S",
  Z = "Z",
  delta_true = estimands_Parast_et_al_2024$delta_MC[2],
  theta_true = estimands_Parast_et_al_2024$theta_MC[2],
  seed = 123,
  n_chains = n_chains,
  n_iter = n_iter,
  burn_in_ratio = burn_in_ratio,
  a = a,
  b = b,
  alpha = alpha,
  beta = beta,
  V_S_zero = V_S_zero,
  BF_alternative = BF_alternative,
  root_tolerance = 1e-16,
  mu_0 = mu_0,
  Sigma_0 = Sigma_0,
  s = s,
  tau = tau,
  plot = TRUE,
  mute = TRUE,
  parallel = TRUE
)

## ----BSET-no-X-plot, echo=FALSE, fig.width=8, fig.height=4.5, fig.align='center', fig.cap="Posterior distribution of $\\theta$ from the BSET procedure without adjusting for covariates. The <span style='color:blue'>blue</span> vertical line indicates the upper bound of the 95% credible interval, the <span style='color:green'>green</span> vertical line indicates value of the validation threshold $\\eta$, the <span style='color:orange'>orange</span> vertical line indicates the true value of $\\delta$, and the <span style='color:red'>red</span> vertical line indicates the true value of $\\theta$."----
# Plot the posterior distribution of theta
BSET_no_X_results$theta_posterior_plot

## ----BSET-X-data--------------------------------------------------------------
# Prepare the data for BSET_X
BSET_X_data <- data.frame(
  Y = data_X$P_observed[, "Y"],
  S = data_X$P_observed[, "S"],
  Z = data_X$Z,
  X = data_X$X
)

## ----BSET-X-prior-parameters--------------------------------------------------
# Prior parameters for the regression coefficients of the potential outcomes on the covariates
d <- 2
mu_beta <- rep(0, d)
Sigma_beta <- 10*diag(d)

## ----BSET-X-------------------------------------------------------------------
# Run the BSET procedure adjusting for covariates
BSET_X_results <- BSET::BSET_X(
  data = BSET_X_data,
  Y = "Y",
  S = "S",
  Z = "Z",
  X = "X",
  delta_true = estimands_Carlotti_and_Parast_2026$delta_MC[1],
  theta_true = estimands_Carlotti_and_Parast_2026$theta_MC[1],
  seed = 123,
  n_chains = n_chains,
  n_iter = n_iter,
  burn_in_ratio = burn_in_ratio,
  a = a,
  b = b,
  alpha = alpha,
  beta = beta,
  V_S_zero = V_S_zero,
  BF_alternative = BF_alternative,
  root_tolerance = 1e-16,
  mu_beta = mu_beta,
  Sigma_beta = Sigma_beta,
  s = s,
  tau = tau,
  plot = TRUE,
  mute = TRUE,
  parallel = TRUE
)

## ----BSET-X-plot, echo=FALSE, fig.width=8, fig.height=4.5, fig.align='center', fig.cap="Posterior distribution of $\\theta$ from the BSET procedure adjusting for covariates. The <span style='color:blue'>blue</span> vertical line indicates the upper bound of the 95% credible interval, the <span style='color:green'>green</span> vertical line indicates value of the validation threshold $\\eta$, the <span style='color:orange'>orange</span> vertical line indicates the true value of $\\delta$, and the <span style='color:red'>red</span> vertical line indicates the true value of $\\theta$."----
# Plot the posterior distribution of theta
BSET_X_results$theta_posterior_plot

