# BSET

`BSET` (Bayesian Surrogate Evaluation Test) is an `R` package for
assessing the validity of surrogate markers in clinical trials. It
provides hypothesis testing tools to evaluate whether a surrogate can
reliably estimate the causal effect of a treatment on a primary outcome.
The package implements the imputation-based Bayesian methodology of
Carlotti and Parast (2026), extending the frequentist rank-based
approach of Parast et al. (2024). BSET addresses key limitations of the
frequentist method, including the lack of causal interpretability and
the inability to adjust for covariates in the estimation process.

The package supports Bayesian testing both with and without baseline
covariates. Additionally, it includes comprehensive simulation suites to
replicate studies from both papers, enabling performance comparisons
between Bayesian and frequentist approaches across diverse clinical
scenarios.

For a detailed walkthrough and examples of the imputation-based
methodology, please visit the [BSET
Tutorial](https://htmlpreview.github.io/?https://github.com/PietroCarlotti/BSET/blob/main/docs/articles/BSET_tutorial.html).
